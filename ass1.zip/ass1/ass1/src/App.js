import logo from './logo.svg';
import './App.css';
import Ang_vs_React from './components/Ang_vs_React';
import Dom_vs_Vir_Dom from './components/Dom_vs_Vir_Dom';
import Lib_vs_frw from './components/Lib_vs_frw';
import Odb_vs_Tdb from './components/Odb_vs_Tdb.js';
import React_Intro from './components/React_Intro';
import Spa_vs_Mpa from './components/Spa_vs_Mpa';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
      <Ang_vs_React/>
      <Dom_vs_Vir_Dom/>
      <Lib_vs_frw/>
      <Spa_vs_Mpa/>
      <React_Intro/>
      <Odb_vs_Tdb/>
    </div>
  );
}

export default  App
