function Lib_vs_frw(){
    return (
<div>
    <h1>framework and a library</h1>
    <p>I always thought of a library as a set of objects and functions that focuses on solving a particular problem or a specific area of application development (i.e. database access); and a framework on the other hand as a collection of libraries centered on a particular methodology (i.e. MVC) and which covers all areas of application development.

</p>
</div>
    )
}
export default Lib_vs_frw;