function React_Intro(){
    return (
<div>
    <h1>React Introduction</h1>
    <p>React is a declarative, efficient, and flexible JavaScript library for building user interfaces. It lets you compose complex UIs from small and isolated pieces of code called “components”. We'll get to the funny XML-like tags soon. ... When our data changes, React will efficiently update and re-render our components.
</p>
</div>
    )
}
export default React_Intro;