function Ang_vs_React(){
    return (
<div>
    <h1>dom vs virtual dom</h1>
    <p>Angular is a Javascript framework built using Typescript, while Reactjs is a Javascript library and built using JSX. Angular is mostly used to build complex enterprise-grade apps like single-page apps and progressive web apps, while React is used to build UI components in any app with frequently variable data.3 days ago
</p>
</div>
    )
}
export default Ang_vs_React;