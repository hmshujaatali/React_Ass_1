function Spa_vs_Mpa() {
    return (
        <div>
            <h1>SPA</h1>
            <a href="https://www.mindk.com/blog/single-page-applications-the-definitive-guide/">click Me</a>


        </div>
    )
}
export default Spa_vs_Mpa;