function Odb_vs_Tdb(){
    return (
<div>
    <h1>ONE WAY DATA BINDING </h1>
    <p>One-way data binding means that React is more performant than Angular and also makes debugging a React app easier than debugging an Angular app, in my opinion. A unidirectional data flow means that when designing a React app you often nest child components within higher-order parent components.
</p>
<br/>
<h1>TWO WAY DATA BINDING </h1>
    <p>Overview. LinkedStateMixin is an easy way to express two-way binding with React. In React, data flows one way: from owner to child. ... Two-way binding — implicitly enforcing that some value in the DOM is always consistent with some React state — is concise and supports a wide variety of applications.
</p>
</div>
    )
}
export default Odb_vs_Tdb;