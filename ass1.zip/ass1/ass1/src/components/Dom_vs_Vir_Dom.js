function Dom_vs_Vir_Dom(){
    return (
<div>
    <h1>dom vs virtual dom</h1>
    <p>The Virtual DOM is a light-weight abstraction of the DOM. You can think of it as a copy of the DOM, that can be updated without affecting the actual DOM. It has all the same properties as the real DOM object, but doesn't have the ability to write to the screen like the real DOM.30-Nov-2020
</p>
</div>
    )
}
export default Dom_vs_Vir_Dom;